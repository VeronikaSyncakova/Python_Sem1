/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.5.2-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: gofishdb
-- ------------------------------------------------------
-- Server version	11.5.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `player`
--

DROP TABLE IF EXISTS `player`;

CREATE TABLE `player` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `handle` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
);


--
-- Dumping data for table `player`
--

LOCK TABLES `player` WRITE;
/*!40000 ALTER TABLE `player` DISABLE KEYS */;
INSERT INTO `player` VALUES
(1,'Joe','jjj'),
(2,'vvvv','vvvv'),
(3,'vvvv','vvvv'),
(4,'sss','s'),
(5,'Veronika Syncakova','v'),
(6,'ss','ss'),
(7,'computer','computer'),
(8,'aaa','a'),
(9,'k','k'),
(10,'Amy','Amy'),
(11,'',''),
(12,'Simon','tojedno'),
(13,'Veronika Syncakova','l'),
(14,'d','d'),
(15,'wewe','w'),
(16,'sasaaaa','sdsd'),
(17,'lllllll','lllll'),
(18,'ed','ed'),
(19,'d','ddd');
/*!40000 ALTER TABLE `player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scores`
--

DROP TABLE IF EXISTS `scores`;

CREATE TABLE `scores` (
  `score` int(11) NOT NULL,
  `ts` timestamp NOT NULL DEFAULT current_timestamp(),
  `player_id` int(11) NOT NULL
);


--
-- Dumping data for table `scores`
--

LOCK TABLES `scores` WRITE;
/*!40000 ALTER TABLE `scores` DISABLE KEYS */;
INSERT INTO `scores` VALUES
(88,'2024-11-11 10:14:29',1),
(16,'2024-11-18 10:04:29',6),
(16,'2024-11-18 10:04:29',6),
(18,'2024-11-18 10:26:59',6),
(18,'2024-11-18 10:26:59',6),
(6,'2024-11-18 10:40:48',6),
(6,'2024-11-18 10:40:48',6),
(12,'2024-11-18 11:05:03',6),
(18,'2024-11-18 11:06:42',7),
(18,'2024-11-18 11:06:42',7),
(20,'2024-11-19 09:32:47',7),
(20,'2024-11-19 09:32:47',7),
(14,'2024-11-19 09:36:04',5),
(14,'2024-11-19 09:36:04',5),
(22,'2024-11-19 09:57:56',5),
(22,'2024-11-19 09:57:56',5),
(18,'2024-11-19 10:39:00',7),
(18,'2024-11-19 10:39:00',7),
(20,'2024-11-20 10:06:55',7),
(20,'2024-11-20 10:06:55',7),
(12,'2024-11-20 10:30:05',10),
(12,'2024-11-20 10:30:05',10),
(6,'2024-11-20 10:32:23',10),
(6,'2024-11-20 10:32:23',10),
(8,'2024-11-20 10:49:57',10),
(8,'2024-11-20 10:49:57',10),
(16,'2024-11-22 19:18:38',12),
(16,'2024-11-22 19:18:38',12),
(18,'2024-11-22 19:25:37',7),
(18,'2024-11-22 19:25:37',7),
(7,'2024-11-25 14:28:43',5),
(7,'2024-11-25 14:28:43',5),
(20,'2024-11-25 14:33:01',6),
(20,'2024-11-25 14:33:01',6),
(6,'2024-11-25 14:41:36',13),
(6,'2024-11-25 14:41:36',13),
(6,'2024-11-25 14:42:39',13),
(6,'2024-11-25 14:42:39',13),
(8,'2024-11-25 14:43:51',6),
(8,'2024-11-25 14:43:51',6),
(6,'2024-11-25 14:44:51',6),
(6,'2024-11-25 14:44:51',6),
(6,'2024-11-25 14:47:23',6),
(6,'2024-11-25 14:47:23',6),
(11,'2024-11-25 14:48:49',5),
(11,'2024-11-25 14:48:49',5),
(7,'2024-11-25 14:50:08',5),
(7,'2024-11-25 14:50:08',5),
(8,'2024-11-25 14:55:31',5),
(8,'2024-11-25 14:55:31',5),
(10,'2024-11-25 15:00:04',5),
(10,'2024-11-25 15:00:04',5),
(9,'2024-11-26 10:23:02',6),
(9,'2024-11-26 10:23:02',6),
(14,'2024-11-27 10:18:21',7),
(14,'2024-11-27 10:18:21',7),
(8,'2024-11-27 10:24:50',6),
(8,'2024-11-27 10:24:50',6),
(7,'2024-11-27 10:49:28',6),
(7,'2024-11-27 10:49:28',6),
(12,'2024-11-27 11:37:10',6),
(12,'2024-11-27 11:37:10',6),
(6,'2024-11-27 11:52:31',6),
(6,'2024-11-27 11:52:31',6),
(5,'2024-12-02 09:46:42',7),
(5,'2024-12-02 09:46:42',7),
(6,'2024-12-02 11:19:00',6),
(6,'2024-12-02 11:19:00',6);
/*!40000 ALTER TABLE `scores` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2024-12-02 15:16:36
